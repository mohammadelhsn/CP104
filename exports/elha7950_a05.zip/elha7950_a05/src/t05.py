"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports

from functions import range_addition

# Call the function

result = range_addition(1, 2, 20)

# Output results

print(result)
