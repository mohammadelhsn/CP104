"""
-------------------------------------------------------
Assignment 5, Task 4

Description: 
    Prints a multiplication table for values from start_num to stop_num.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports

from functions import multiplication_table

# Call the function, Output results

multiplication_table(2, 4)
