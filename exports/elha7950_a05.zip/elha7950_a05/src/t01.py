"""
-------------------------------------------------------
Assignment 5, Task 1

Description: 
    Calculates and returns the factorial of number.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports

from functions import calc_factorial

# Call the function

result = calc_factorial(5)

# Output result

print(result)
