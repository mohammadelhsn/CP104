"""
-------------------------------------------------------
Assignment 5, Task 3

Description: 
    arrow_up takes an integer parameter and prints a arrow of # characters pointing up.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports

from functions import arrow_up

# Call the function, Output results

arrow_up(4)
