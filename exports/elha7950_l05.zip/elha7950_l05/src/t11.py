"""
-------------------------------------------------------
Lab 5, Task 11

Description: 
    Determines location on a plane of an x, y coordinate.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports

from functions import quadrant

# Call the function

result = quadrant(0, -3)

# Output results

print(result)
