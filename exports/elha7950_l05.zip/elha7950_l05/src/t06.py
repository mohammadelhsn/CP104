"""
-------------------------------------------------------
Lab 5, Task 6

Description: 
    Determines if n is evenly divisible by both i and j
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports

from functions import is_divisible

# Call the function

result = is_divisible(15, 3, 5)

# Output results

print(result)
