"""
-------------------------------------------------------
Lab 5, Task 8

Description:
    Convert 1-10 to Roman numerals.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports

from functions import roman_numeral

# Call the function

result = roman_numeral(7)

# Output results

print(result)
