"""
-------------------------------------------------------
Lab 9, Task 7

Description:
    Counts the number of vowels in a string. Does not include 'y'.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-14"
-------------------------------------------------------
"""
# Imports

from functions import vowel_count

# Call the function

result = vowel_count('aeiouy')

# Output results

print(result)
