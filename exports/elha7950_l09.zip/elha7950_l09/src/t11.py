"""
-------------------------------------------------------
Lab 9, Task 11

Description: 
    Disemvowels a string. Returns a copy of s with all the vowels
    removed. Y is not treated as a vowel. Preserves case.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports

from functions import dsmvwl

# Call the function

result = dsmvwl('I think your book is an utter piece of garbage.')

# Output result

print(result)
