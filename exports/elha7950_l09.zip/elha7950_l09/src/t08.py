"""
-------------------------------------------------------
Lab 9, Task 8

Description: 
    Counts the number of digits in a string.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports

from functions import digit_count

# Call the function

result = digit_count('I know 1 thing - there are 2 kinds of people.')

# Output result

print(result)
