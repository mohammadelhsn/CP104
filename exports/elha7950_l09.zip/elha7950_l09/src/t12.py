"""
-------------------------------------------------------
Lab 9, Task 12

Description: 
    Replaces all the commas with a period in s.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports

from functions import comma_period_replace

# Call the function

result = comma_period_replace('Number 1, Number 2, Number 3,')

# Output results

print(result)
