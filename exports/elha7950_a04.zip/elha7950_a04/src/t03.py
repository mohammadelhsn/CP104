"""
-------------------------------------------------------
Assignment 4, Task 3

Description:
    Returns the average of the two largest values of
    val1, val2, and val3.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import largest_average

# Call the function

result = largest_average(-8.0, 12.0, 20.0)

# Output values

print(result)
