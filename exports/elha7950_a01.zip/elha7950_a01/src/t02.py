"""
-------------------------------------------------------
Assignment 1, Task 2

Description: 
    This program asks the user for their age and their favourite band, in that 
    order, and then prints their answers
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""

# Get the user input

age = int(input("What is your age? "))
fav_band = input("What is your favourite band? ")

# Output the results

print()
print(f"I am {age} years old and {fav_band} is my favourite band.")
