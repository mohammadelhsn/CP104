"""
-------------------------------------------------------
Lab 3, Task 1

Description: 
    Write Python code that uses a single print function and triple double  quotes to print the following output:

    'I'm a Little Astronaut' by Jean Warren

    I'm a little astronaut
        Flying to the moon.
            My rocket is ready,
            We blast off soon.
    I climb aboard
        And close the hatch.
            5-4-3-2-1, off we blast!
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""

# Output results

print("""'I'm a Little Astronaut' by Jean Warren

I'm a little astronaut
    Flying to the moon.
        My rocket is ready,
        We blast off soon.
I climb aboard
    And close the hatch.
        5-4-3-2-1, off we blast!""")
