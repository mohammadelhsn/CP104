"""
-------------------------------------------------------
Lab 3, Task 2

Description: 
    Write Python code that uses multiple print functions (one per line) and double quotes to print 
    the following output:
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""

# Output results

print("'Twinkle Twinkle Little Star' by Jane Taylor")
print()
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
print("        Up above the world so high,")
print("        Like a diamond in the sky.")
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
