"""
-------------------------------------------------------
Lab 3, Task 3 

Description:
    Selected quotes from Mark Twain:

    "Do the right thing. It will gratify some people and astonish the rest."
    "All generalizations are false, including this one."
    "It is better to keep your mouth closed and let people think you are a fool
    than to open it and remove all doubt."
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-18"
-------------------------------------------------------
"""

# Output results

print('Selected quotes from Mark Twain:')
print()
print('"Do the right thing. It will gratify some people and astonish the rest."')
print('"All generalizations are false, including this one."')
print('"It is better to keep your mouth closed and let people think you are a fool')
print('than to open it and remove all doubt."')
