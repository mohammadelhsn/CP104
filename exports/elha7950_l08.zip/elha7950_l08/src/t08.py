"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import linear_search

# Call the function

result = linear_search([94, 96, -22, -79, -28, -26, -50, 71, 24, -32], -22)

# Output results

print(result)
