"""
-------------------------------------------------------
Lab 8, Task 10

Description:
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import min_search

# Constants

result = min_search([94, 96, -32, -19, -28, 96, -22, 71, 24, -32])

# Output results

print(result)
