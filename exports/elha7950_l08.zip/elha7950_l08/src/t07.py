"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import list_categorize

# Call the function

result = list_categorize([94, 96, -22, -79, -28, -26, -50, 71, 24, -32])

# Output results

print(result)
