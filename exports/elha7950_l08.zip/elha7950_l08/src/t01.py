"""
-------------------------------------------------------
Lab 8, Tasks 1-15

Description: 
    Returns the name of a day of the week given its number.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import get_weekday_name

# Call the function

result = get_weekday_name(2)

# Output results

print(result)
