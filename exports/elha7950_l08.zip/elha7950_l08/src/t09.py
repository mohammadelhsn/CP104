"""
-------------------------------------------------------
Lab 8, Task 9

Description: 
    Searches through values for value and returns a list of
    all indexes of its occurrence.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import many_search

# Call the function

result = many_search([94, 96, -22, -79, -28, 96, -50, 71, 24, -32], 96)

# Output results

print(result)
