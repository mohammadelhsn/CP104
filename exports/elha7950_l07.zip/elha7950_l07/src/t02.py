"""
-------------------------------------------------------
Lab 7, Task 2

Description: 
    Determines the nearest power of 2 greater than or equal to
    a given target.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-31"
-------------------------------------------------------
"""
# Imports

from functions import power_of_two

# Call the function

result = power_of_two(3)

# Output results

print(result)
