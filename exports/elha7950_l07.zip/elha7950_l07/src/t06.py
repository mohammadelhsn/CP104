"""
-------------------------------------------------------
Lab 7, Task 6

Description: 
    Asks a user to enter a series of numbers, then counts and returns
    how may positives, negatives, and zeroes there are.
    Stop processing values when the user enters -999.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-31"
-------------------------------------------------------
"""
# Imports

from functions import num_categories

# Call the function

result = num_categories()

# Output results

print(result)
