"""
-------------------------------------------------------
Lab 7, Task 1

Description: 
    Plays a random higher-lower guessing game.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-31"
-------------------------------------------------------
"""
# Imports

from functions import hi_lo_game

# Call the function, Output results

hi_lo_game(100)
