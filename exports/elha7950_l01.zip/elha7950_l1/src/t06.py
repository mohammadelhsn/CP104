"""
-------------------------------------------------------
Task 1, Lab 6

Description: 
    Calculate total pay.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-11"
-------------------------------------------------------
"""

# Calculate total pay
salary = 2500.0
bonus = 1200.0
pay = salary + bonus
print('Your pay is', pay)


# ALWAYS USE CREATE NEW PYTHON MODULE!!!!!!!!!!!!!!
# CANNOT FORGET THE HEADER WHEN YOU HAND IN AN ASSIGNMENT!!!
