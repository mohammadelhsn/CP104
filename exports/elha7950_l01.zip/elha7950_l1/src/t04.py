"""
-------------------------------------------------------
Lab 1, Task 4

Description: Print out the entered name
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-11"
-------------------------------------------------------
"""

# Get user input

name = input("Please enter your name: ")

# Output

print("Pleased to meet you ")
print(name)
