"""
-------------------------------------------------------
Lab 6, Task 7

Description: 
    Prints a triangle of width characters using
    the char character.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import draw_arrow

# Call the function, Output results

draw_arrow(6, '*')
