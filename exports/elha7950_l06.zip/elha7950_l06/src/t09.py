"""
-------------------------------------------------------
Lab 6, Task 9

Description: 
    Prints n verses of the song "99 Bottles of Beer on the Wall".
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import bottles_of_beer

# Call the function, Output results

bottles_of_beer(99)
