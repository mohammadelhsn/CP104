"""
-------------------------------------------------------
Lab 6, Task 6

Description: 
    Prints a triangle of height characters using
    the char character.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import draw_triangle

# Call the function, Output values

draw_triangle(6, "$")
