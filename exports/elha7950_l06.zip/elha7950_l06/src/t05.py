"""
-------------------------------------------------------
Lab 6, Task 5

Description: 
    Prints a rectangle of height and width characters using
    the char character.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import draw_rectangle

# Call the function, Output results

draw_rectangle(3, 12, '#')
