"""
-------------------------------------------------------
Lab 6, Task 2

Description: 
    Sums and returns the total of all odd numbers from 1 to num (inclusive).
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import sum_odd

# Call the function

result = sum_odd(123)

# Output values

print(result)
