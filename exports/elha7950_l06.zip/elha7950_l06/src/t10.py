"""
-------------------------------------------------------
Lab 6, Task 10

Description: 
    Calculates and prints calories burnt on a treadmill over
    a given time range.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import treadmill

# Call the function, Output results

treadmill(3.9, 5, 30, 5)
