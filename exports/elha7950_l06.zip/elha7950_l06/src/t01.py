"""
-------------------------------------------------------
Lab 6, Task 1

Description: 
    Sums and returns the total of all even numbers from 2 to num (inclusive).
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-22"
-------------------------------------------------------
"""
# Imports

from functions import sum_even

# Call the function

result = sum_even(123)

# Output values

print(result)
