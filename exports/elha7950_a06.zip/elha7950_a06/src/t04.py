"""
-------------------------------------------------------
Assignment 6, Task 4

Description: 
    Counts the number of digits in an integer.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import count_of_digits

# Call the function

result = count_of_digits(-1024)

# Output result

print(result)
