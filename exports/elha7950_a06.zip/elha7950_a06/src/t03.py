"""
-------------------------------------------------------
Assignment 6, Task 3

Description: 
    Prints a table of monthly interest and payments on a loan.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import interest_table

# Call the function

result = interest_table(750, 8.5, 200)
