"""
-------------------------------------------------------
Assignment 6, Task 1

Description: 
    Returns wins for purple and gold. Type enter if you 
    wish to quit.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import total_wins

# Call the function

result = total_wins()

# Output results

print(result)
