"""
-------------------------------------------------------
Assignment 6, Task 2

Description: 
    Determines if number is a prime number.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

from functions import detect_prime

# Call the function

result = detect_prime(131)

# Output results

print(result)
