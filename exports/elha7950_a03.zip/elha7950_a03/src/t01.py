"""
-------------------------------------------------------
Assignment 3, Task 1

Description: 
    Converts square footage to acres.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports

from functions import footage_to_acres

# Call the function

result = footage_to_acres(100000.0)

# Output results

print(result)
