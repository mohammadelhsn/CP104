"""
-------------------------------------------------------
Assignment 3, Task 3

Description:
    Extracts the year, month, and day from a date number in the format YYYYMMDD.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports

from functions import extract_date

# Call the function

result = extract_date(19621025)

# Output results

print(result)
