"""
-------------------------------------------------------
Assignment 3, Task 4

Description:
    Calculates and returns fraction values.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports

from functions import multiply_fractions

# Call the function

result = multiply_fractions(1, 2, 3, 4)

# Output results

print(result)
