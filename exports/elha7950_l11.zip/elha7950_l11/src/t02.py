"""
-------------------------------------------------------
Lab 11, Task 2

Description: 
    Generates a 2D list of random lower case letter ('a' - 'z') values
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""
# Imports

from functions import generate_matrix_char

# Call the function

matrix = generate_matrix_char(3, 4)

# Output result

print(matrix)