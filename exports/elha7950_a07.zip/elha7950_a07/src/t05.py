"""
-------------------------------------------------------
Assignment 7, Task 5

Description: 
    Determines whether a list is sorted.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports

from functions import verify_sorted

# Call the function

result = verify_sorted([23, 41, 99])

# Output results 

print(result)