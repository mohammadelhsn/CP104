"""
-------------------------------------------------------
Assignment 7, Task 3

Description: 
    Finds the indexes of target_number in numbers.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports

from functions import get_indexes

# Call the function

result = get_indexes([5, 1, 8, 9, 5, 2, 5, 3], 5)

# Output results

print(result)
