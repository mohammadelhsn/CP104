"""
-------------------------------------------------------
Lab 4, Task 9 

Description: 
    Calculates and returns fraction values.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import fraction_product

# Call the function

results = fraction_product(1, 2, 4, 5)

# Output results

print(results)
