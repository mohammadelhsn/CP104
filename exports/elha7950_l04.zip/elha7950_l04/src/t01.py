"""
-------------------------------------------------------
Lab 4, Task 1

Description: 
    Calculates and returns diameter of a circle.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import diameter

# Call the function

result = diameter(2.5)

# Output results

print(result)
