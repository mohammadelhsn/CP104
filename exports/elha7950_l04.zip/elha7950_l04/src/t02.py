"""
-------------------------------------------------------
Lab 4, Task 2

Description: 
    Calculates and returns circumference of a circle.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import circumference

# Call the function

result = circumference(2.5)

# Output results

print(round(result))
