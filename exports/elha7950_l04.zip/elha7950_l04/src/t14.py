"""
-------------------------------------------------------
Lab 4, Task 14

Description: 
    Returns seconds in different formats.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import time_values

# Call the function

results = time_values(956000)

# Output results

print(results)
