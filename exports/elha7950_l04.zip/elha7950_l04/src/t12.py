"""
-------------------------------------------------------
Lab 4, Task 12

Description: 
    Converts temperatures in celsius to fahrenheit.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import c_to_f

# Call the function

results = c_to_f(0)

# Output results

print(results)
