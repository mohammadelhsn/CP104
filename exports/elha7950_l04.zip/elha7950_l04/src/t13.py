"""
-------------------------------------------------------
Lab 4, Task 13

Description: 
    Converts temperatures in fahrenheit to celsius.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import f_to_c

# Call the function

results = f_to_c(32)

# Output results

print(results)
