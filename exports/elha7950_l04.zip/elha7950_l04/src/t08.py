"""
-------------------------------------------------------
Lab 4, Task 8

Description: 
    Calculates purchase costs of computers
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import computer_costs

# Call the function

results = computer_costs(1399, 87, 8.5)

# Output results

print(results)
