"""
-------------------------------------------------------
Lab 4, Task 15

Description:
    Converts total seconds into days, hours, minutes, and seconds.
-------------------------------------------------------
Author:  Mohammad El-Hassan
ID:      169067950
Email:   elha7950@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""
# Imports

from functions import time_split

results = time_split(956000)
print(results)
